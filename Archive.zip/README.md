# professional readme generator
  

  ##Description
  creates professional grade READMEs for your project!

## Table of Contents
- [Installation](#installation)
- [Usage](#usage)
- [License](#license)
- [Contributing](#contributing)
- [Tests](#tests)
- [Questions](#questions)

## Installation
copy the url from the repository and run the command git clone. once that is done, you can run node index.js

## Usage
if you're ever in doubt for what your README.md should look like while working on a project, simply use this tool to instantly receive a well done and thoughtful readme!

## License
    
    This project is licensed under the [] () license.

## Contributing


## Tests


## Questions
If you have any questions, please feel free to contact me at [name@name.com](mailto:name@name.com). You can also find more of my work at [lukemaines](https://github.com/lukemaines).

## Video Example
<iframe src="https://drive.google.com/file/d/1BDTAp68m17kyup09yl3lMB24-LPzdESu/preview" width="640" height="480"></iframe>